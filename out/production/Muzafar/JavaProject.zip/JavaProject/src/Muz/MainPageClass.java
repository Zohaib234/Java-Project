package  Muz;
import java.util.*;

public class MainPageClass {
    Scanner scanner;
    String choice;
    String name;
    String pass;
    String email;
    String no;

    void logInPage(){
        System.out.println("1:Log In\n2:Sign Up");
        String choice =scanner.next();
        if(choice.equals("1")){
            System.out.println("Enter User Name:");
            name = scanner.nextLine();
            System.out.println("Enter User Password");
            pass = scanner.nextLine();


        }
        else if (choice.equals("2")) {
            System.out.println("Enter User Name:");
            name = scanner.nextLine();
            System.out.println("Enter User Password");
            pass = scanner.nextLine();
            System.out.println("Enter Recovery Number");
            no = scanner.nextLine();
            System.out.println("Enter Your Email:");
            email = scanner.nextLine();
            System.out.println("Enter Your Favourite Book Name:");
            name = scanner.nextLine();
        }
        else {
            System.out.println("Sorry Something Went Wrong!!!! Try Again");
            logInPage();
        }

    }
}
